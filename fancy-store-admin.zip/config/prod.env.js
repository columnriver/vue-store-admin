module.exports = {
    NODE_ENV: '"production"',
    ENV_CONFIG: '"prod"',
    // BASE_API: '"http://localhost:9093/"'
    BASE_API: '"http://www.fancystore.cn/"'
    // BASE_API: '"http://172.100.100.36:9093/"'
}
